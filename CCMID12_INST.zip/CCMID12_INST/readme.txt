######################################################################
                CASIO USB MIDI Driver (Version 1.2)
              (C) 2004-2014 CASIO COMPUTER CO., LTD.
       Company and product names used herein are trademarks of
                     their respective owners. 
######################################################################


This document explains how to install the USB driver required to transfer
MIDI data between an instrument that supports USB connections and a
computer.Installation of the USB driver is available for the model that 
comes with the CD-ROM. Use the following instructions to install the USB 
driver on your computer.


* Supported Operating Systems

Windows 8.1 (32bit)
Windows 8 (32bit)
Windows 7 (32bit)
Windows Vista (32bit)

* To Install the USB driver

1. Log on to Windows using a computer administrator account. See the
documentation that comes with Windows for information
about computer administrators.

2. Confirm that the instrument is not connected to the PC and is turned off.

3. Open the "CCMID12_INST" folder and double-click "dpinst.exe".
(Not "dpinst.xml". If you want to show file extensions, Please refer to
mark (*).)

(For Windows 7,in response to the confirmation dialog box "Do you want to allow
the following program from an unknown publisher to make changes to this
computer?" appears on your computer, click "Yes."
For Windows Vista, in response to the confirmation dialog box "An unidentified
program wants access to your computer", click "Allow.")

4. When the message "Device Driver Installation Wizard" appears, click
"Next."

5. When the message "The drivers are now installing..." appears and then
the message "Windows can't verify the publisher of this driver software"
appears. Click "Install this driver software anyway" and wait until
the message "Completing the Device Driver Installation Wizard" appears.
Click "Finish."

6. Connect the instrument to the computer with the USB cable and turn on
the instrument. Check to make sure that the "Installing device driver
software" message is displayed near the task tray (normally in the lower
right corner of your computer screen). When the message changes to
"CASIO USB MIDI", the USB driver is installed completely.
When the instrument is connected to any USB port, the USB driver will be
initialized automatically.

(*) To show file extensions to distinguish files

1. Open an optional folder and click "Folder and search options" in
"Organize" from menu (normally in the upper left on the folder).

2. When Folder Options appears, click the tab "View."

3. Uncheck "Hide extensions for known file types" in advanced
settings and click "OK." It enables the displaying of extensions,
(e.g.".exe",".xml") and if you want to install this USB driver, double-click 
"dpinst.exe."

* To Uninstall the USB driver

1. Click [Start] -> [Control Panel] -> [Uninstall a program].

2. Check the installed program list and double-click "Windows Driver Package - 
CASIO COMPUTER CO.,LTD. (PL-40R) MEDIA."
(For Windows Vista, in response to the confirmation dialog box "Windows needs
your permission to continue (If you started this action, continue.)"appears
on your computer, click "continue.")

3. When the message "Uninstall Driver Package (All devices using this
driver will be removed. Do you wish to continue?)"appears, click "Yes,"
and wait until uninstallation of the driver is complete.

4. Restart Windows.
